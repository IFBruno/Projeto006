package br.edu.ifsul.cstsi.projeto006;

import br.edu.ifsul.cstsi.projeto006.socio.SocioController;
import java.util.Scanner;

public class HomeController {
    private static final Scanner input = new Scanner(System.in);
    public static void main(String[] args) {
        int opcao;
        do {
            System.out.print("\n----------  Início ----------");
            System.out.print(
                    """ 
                           
                        1. Socios
                        2. Categorias
                        3. Mensalidades
                        
                        Opção (Zero p/sair):\s""");

            opcao = input.nextInt();
            input.nextLine();
            switch (opcao) {
                case 1 -> SocioController.main(null);
                case 2 -> System.out.println("Em Desenvolvimento -> Categorias");
                case 3 -> System.out.println("Em Desenvolvimento -> Mensalidades");
                default -> {
                    if (opcao != 0) System.out.println("Opção Inválida.");
                }
            }
        } while(opcao != 0) ;
        System.out.println("\n\n---------- Fim da Aplicação ----------");
        input.close();
    }
}
