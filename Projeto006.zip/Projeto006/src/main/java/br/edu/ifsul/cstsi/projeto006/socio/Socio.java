package br.edu.ifsul.cstsi.projeto006.socio;

import jakarta.persistence.*;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "socios")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Socio {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cartao;
    private String nome;
    private String endereco;
    private String telefone;
    private String email;

}
