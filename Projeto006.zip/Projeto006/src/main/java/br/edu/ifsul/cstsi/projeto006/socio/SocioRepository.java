package br.edu.ifsul.cstsi.projeto006.socio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface SocioRepository extends JpaRepository<Socio,Long> {
    @Query(value = "SELECT s FROM Socio s where s.nome like ?1")
    List<Socio> findByNome(String nome);
}

